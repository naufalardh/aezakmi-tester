var running = false;
var tabIDs = [];
var d = 0;
var count = 0;

function createTab(url) {
	chrome.tabs.create({url: url, active: false}, function(tab){
		tabIDs.push(tab.id);
		console.log('tab created: ' + tab.id);
    });
}

function check(tabId) {
	for (let i = 0; i < tabIDs.length; i++) {
		if (tabId == tabIDs[i]) {
			count += 1;
			
			console.log('starting tab: ' + tabId);
		
			chrome.tabs.sendMessage(tabId, {
				start: true
			});
			
			if (count == d) {
				running = false;
				console.log('processed all tabs: \n' + tabIDs);
			}
		}
	}
	
}

function startIt(d) {
	if (d > 0) {
		running = true;
		count = 0;
		
		console.log('STARTING - Total Tabs: ' + d);
		
		chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
			
			chrome.tabs.sendMessage(tabs[0].id, {
				start: true
			});
			
			for (let i = 0; i < d; i++) {
				createTab(tabs[0].url);
			}
		});
	} else {
		alert('Invalid Count: ' + d);
	}
	
}

chrome.runtime.onMessage.addListener(function(msg, sender) {
	if ((msg.state === 'scriptInjected') && running) {
		check(sender.tab.id);
	} else if (msg.state === 'startIt') {
		startIt(msg.count);
	}
});

console.log('ext ready...');