
function initialize() {
	chrome.storage.local.get("count", function(s){
		if (s.count) {
			console.log("Loaded Count: " + s.count);
			document.getElementById('count').value = s.count; //if found, set count
		}
	});
}

function startIt(count) {
	chrome.storage.local.set({ count: count }, function(){
		console.log('Saved Count: \n' + count);
		
		chrome.runtime.sendMessage({
			state: 'startIt',
			count: count
		});
	});
}

document.addEventListener('DOMContentLoaded', function() {
	initialize();
	
    document.getElementById('startIt').addEventListener('click', function() {
		
		startIt(parseInt(document.getElementById('count').value));
		
    }, false);
}, false);

console.log('Script Ready.');