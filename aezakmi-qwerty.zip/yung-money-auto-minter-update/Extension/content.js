var running = false;

async function startIt() {
	console.log('started');

	let wait = 30;
	let count = 0;
	
	//let btn = document.getElementsByClassName('MuiButton-label');
	let btn = document.getElementsByTagName('button');
	
	let check = window.setInterval( function() {
		if (btn.length > 0) {
			for (let i = 0; i < btn.length; i++) {
				if (btn[i].innerText.toLowerCase().includes('mint')) {
					window.clearInterval(check);
					
					running = false;
					console.log('btn found. clicking btn index: ' + i);
					
					btn[i].click();
					
					let verifyCount = 1;
					
					let verify = window.setInterval( function() {
						if (btn[i].innerText.toLowerCase().includes('mint')) {
							if (verifyCount > 5) {
								window.clearInterval(verify);
								console.log('retry attempts limit reached for clicking btn index: ' + i);
							} else {
								btn[i].click();
								console.log(verifyCount + 'attempt clicking btn index: ' + i);
								verifyCount += 1;
							}
						} else {
							window.clearInterval(verify);
							console.log('clicked btn index: ' + i);
						}
					}, 1000);
				}
			}
		}
		
		if (check) {
			if ((count > (wait * 2)) || !running) {
				window.clearInterval(check);
				
				if (!running) {
					console.log('Completed: ' + Date());
				} else {
					console.log('Timeout at: ' + Date());
					running = false;
				}
			} else {
				count += 1;
				console.log('Waiting: ' + count);
			}
		}
	}, 500);
}

chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.start) {
        console.log('ext starting: ' + Date());
		
		if (!running) {
			running = true;
			startIt();
		}
    }
});

chrome.runtime.sendMessage({
	state: 'scriptInjected'
});

console.log('script ready: ' + Date());
