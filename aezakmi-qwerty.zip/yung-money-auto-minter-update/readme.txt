1) Download and extract (doesn't matter where)

2) Go to Chrome > Menu > More Tools > Extensions

3) Enable Developer mode and click "Load Unpacked" button, select the extension folder(not yung money minter folder).

4) Extension should be loaded.
Visit a website having MINT button.

5) Click on yung money icon, a popup will appear.

6) Enter how many mints you would like +-1 and click mint.

note: It works a lot better with auto approve on.
+ with fast internet and a solid rig.